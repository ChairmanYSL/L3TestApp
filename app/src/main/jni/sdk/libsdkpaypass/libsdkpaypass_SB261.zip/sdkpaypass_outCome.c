#include "dllemvbase.h"
#include "dllpaypass.h"
#include "dllpaypassprivate.h"

#include "dllemvbasetagbaselib.h"

#include "sdkGlobal.h"
#include "sdkemvbaseprivate.h"
#include "sdkpaypassprivate.h"
#include "sdkpaypass_outCome.h"

#include "transflowparseprotocol.h"
#if 1

    //20130117add
    #define COMMAND_PAYPASS_USERREQDATA         0xEF
    #define COMMAND_PAYPASS_DISCRENTDATA        0xEE
    #define COMMAND_PAYPASS_OUTPARAMSET         0xED
    #define COMMAND_PAYPASS_CLEANSIGNAL         0xEC
    #define COMMAND_UPDATEAPPLICATION           0xEB
    #define COMMAND_PAYPASS_FORCECLEANSIGNAL    0xE9  //sxl20150722
    #define COMMAND_PAYPASS_LOOPTRANS           0xE0
    #define COMMAND_PAYPASS_PARAMSET            0xDF
    #define COMMAND_PAYPASS_CANCEL              0xDE

    #define COMMAND_PAYPASS                     0xFA


    #define qPBOC_READAIDPARAMETERS   169
    #define qPBOC_OTHERAPCARD         170
    #define qPBOC_RESETCOMMAND        171
    #define qPBOC_RESETFAIL           172
    #define qPBOC_DETECTCARDOVERTIME  173
    #define qPBOC_MULTICARD           174
    #define qPBOC_OTHERERR            175
    #define qPBOC_COMPLETE            176
    #define qPBOC_RECEIVEDOVERTIME    177
    #define qPBOC_READCARDERR         178
    #define qPBOC_RECEIVEBAGERR       179



    ////////response code
    #define RC_SUCCESS                          0x00
    #define RC_DATA                             0x01
    #define RC_POLL_A                           0x02
    #define RC_POLL_P                           0x03
    #define RC_SCHEME_SUPPORTED                 0x04
    #define RC_SIGNATURE                        0x05
    #define RC_ONLINE_PIN                       0x06
    #define RC_OFFLINE_PIN                      0x07
    #define RC_SECOND_APPLICATION               0x08

    #define RC_PAYPASSDECLINE                   0x50
    #define RC_PAYPASSENDAPPLICATION            0x51


    #define RC_OTHER_INTERFACE                  0xE9
    #define RC_INVALID_JCB_CA_KEY               0xEA
    #define RC_NO_SIG                           0xEB
    #define RC_NO_PIN                           0xEC
    #define RC_US_CARDS                         0xED
    #define RC_Other_AP_CARDS                   0xEE
    #define RC_POLL_N                           0xEF
    #define RC_NO_PARAMETER                     0xF0
    #define RC_NO_PBOC_TAGS                     0xF1
    #define RC_NO_CARD                          0xF2
    #define RC_MORE_CARDS                       0xF3
    #define RC_INVALID_VISA_CA_KEY              0xF4
    #define RC_INVALID_SCHEME                   0xF5
    #define RC_INVALID_KEYINDEX                 0xF6
    #define RC_INVALID_PARAM                    0xF7
    #define RC_INVALID_DATA                     0xF8
    #define RC_INVALID_COMMAND                  0xF9
    #define RC_DDA_AUTH_FAILURE                 0xFA   //sxl?�����û�д���
    #define RC_AUTH_NOT_PERFORMED               0xFB
    #define RC_AUTH_FAILURE                     0xFC
    #define RC_ACCESS_FAILURE                   0xFD
    #define RC_ACCESS_NOT_PERFORMED             0xFE
    #define RC_FAILURE                          0xFF
    #define RC_DECLINE                          0x0F
    #define RC_ERR_LASTRECORD                   0x0E
    #define RC_ONLINEDEAL                       0x0D
    #define RC_ErrTransDisp                     0x0C
    #define RC_NO_PSE                           0x09
    #define RC_CARDNO                           0x0B
    #define RC_SMVERIFY                         0x0A
    #define RC_REBUILDLIST                      0x2A
    #define RC_TRADERESET                       0x2B
    #define RC_UNSUPPORTCARD               0x2C


    #define COMMAND_POLL                        0x07
    #define COMMAND_PAYRESET                    0x31
    #define COMMAND_DISPLAYSTATUS               0x32
    #define COMMAND_DEALONLINE                  0x33


    #define PAYPASSAPP   0

    #define TRADETYPE_PAYPASSMAGPREPAY  0x06
    #define TRADETYPE_PAYPASSCHIPPREPAY 0x07

#endif


#if 1

u8 gpaypasscanceltrade = 0;


extern PaypassTornTransactionLogRecord *pPaypasstorntransactionlogrecord;
extern PAYPASSDLLTRADEPARAMETER *gstPaypassTradeParam;

#ifdef PAYPASS_OUTCOME_SUPPORT_FLAG
    extern PAYPASS_USERINTERFACEREQDATA gPaypassUserInterfaceReqData;
#endif
extern PAYPASS_OUTPARAMETERSET gPaypassOutParameterSet;
extern PAYPASS_OUTCOME_ERRORID gstPaypassOutComeErrID;
extern PAYPASS_PHONEMESSAGETABLEINFO gPaypassPhoneMessageTableInfo;
extern PAYPASS_APDU_ERRORID gPaypassApduErrorID;



extern u8 Rx_Valid;
extern COMMUNICATEDATA gCommData;
extern u8 gSerialNo;

u8 transflowb_formsendpaypasspredata(u8 *carddata, u32 *carddatalen);



//---------------------------------------------------------------------------------------------------------------------//
static void Packbertlvdata(unsigned char *dstdata, unsigned int *dstdatalen, unsigned char *tag, unsigned char taglen, unsigned char *srcdata, unsigned int srcdatalen)
{
    unsigned int len = 0, pos = 0;
    unsigned int t, j;


    pos = *dstdatalen;
    memcpy((unsigned char *)&dstdata[pos], (unsigned char *)&tag[0], taglen);
    pos += taglen;

    len = srcdatalen;
    if(len < 128)
    {
        dstdata[pos++] = len;
    }
    else
    {
        t = 0;
        while(len)
        {
            t++;
            len = len >> 8;
        }
        dstdata[pos++] = 0x80 | t;
        len = srcdatalen;
        for(j = t; j > 0; j--)
        {
            dstdata[pos + j - 1] = len % 256;
            len = len >> 8;
        }

        pos += t;
    }
    if(srcdata != NULL)
    {
        memcpy(&dstdata[pos], srcdata, srcdatalen);
        pos += srcdatalen;
    }

    *dstdatalen = pos;


}


u32 sdkPaypasstransfertimervalue(u32 timervalue)
{
    return ((timervalue + TIMERINTERVAL - 1) / TIMERINTERVAL);
}

u8 sdkpaypassmanagerecord_endapplication(u8 type, u8 *senddata, u32 senddatalen)
{
    if(type == PAYPASSAPP)
    {
        senddata[0] = 3;//Msg_EMV_Confirm;   //������Ҫ�ı�
        transflow_tradeoversendpaypassbag(senddata, senddatalen + 1);
    }


    return RC_SUCCESS;
}

//20140222
void sdkPaypassOutComeSendendapplicationdatarecord(void)
{

    s32 ret;
    u8 *returndata;  //[1024]
    u32 returndatalen;

    returndata = (u8 *)emvbase_malloc(1024);

    //	gEMVTradeParam->TransResult = OFFLINE_DECLINE;
    gstPaypassTradeParam->TransResult = RLT_EMV_OFFLINE_DECLINE;


    ret = sdkPaypassOutComeformsendpaypasspredata(&returndata[1], &returndatalen);
    if(ret == RC_SUCCESS)
    {
        ret = sdkpaypassmanagerecord_endapplication(PAYPASSAPP, returndata, returndatalen);
    }

    emvbase_free(returndata);

}

void sdkpaypassb_sendoutMeasuredRRPtimeparamset(u32 step)
{
    unsigned char tmpdata[1024];
    unsigned int len = 0;
    unsigned short exist = 0;
    EMVBASETAGCVLITEM *tagitem;
    #ifdef EMVB_DEBUG
    unsigned int i;
    #endif

    memset(tmpdata, 0, sizeof(tmpdata));
    EMVBaseU32ToBcd(tmpdata, step, 4);
    len += 4;

    memcpy(&tmpdata[len], "\xDF\x83\x06", 3);
    len += 3;


    exist = 0;
    tagitem = emvbase_avl_gettagitempointer(EMVTAG_MeasureRelayResistanceProcessingTime);
    if(tagitem != NULL)
    {
        if(tagitem->len > 0)
        {
            exist = 1;
        }
    }
    if(0 == exist)
    {
        #ifdef EMVB_DEBUG
        Trace("", "\r\n EMVTAG_MeasureRelayResistanceProcessingTime = null,so exit send func \r\n");
        #endif
        return ;
    }

    tmpdata[len++] = 2;

    memcpy(&tmpdata[len], &tagitem->data[0], 2);
    len += 2;

    #if 1 /*Modify by luohuidong at 2019.04.01  17:59 */
    exist = 0;
    tagitem = NULL;
    tagitem = emvbase_avl_gettagitempointer(EMVTAG_TerminalRelayResistanceEntropy);
    if(tagitem != NULL)
    {
        if(( tagitem->len > 0) && ( 0 != memcmp(&tagitem->data[0], "\x00\x00\x00\x00", 4)))
        {
            memcpy(&tmpdata[len], "\xDF\x83\x01", 3);
            len += 3;

            tmpdata[len++] = tagitem->len;
            memcpy(&tmpdata[len], &tagitem->data[0], tagitem->len);
            len += tagitem->len;
            exist = 1;
        }
    }
    if(exist)
    {
        tagitem = NULL;
        tagitem = emvbase_avl_gettagitempointer(EMVTAG_RRPCounter);
        if(tagitem != NULL)
        {
            if( tagitem->len > 0 )
            {
                memcpy(&tmpdata[len], "\xDF\x83\x07", 3);
                len += 3;

                tmpdata[len++] = tagitem->len;
                memcpy(&tmpdata[len], &tagitem->data[0], tagitem->len);
                len += tagitem->len;
            }
        }
    }

    #endif

    Trace("", "gpaypasscanceltrade=%d", gpaypasscanceltrade);
    TraceHex("", "paypass_sendoutparamset,tmpdata:", tmpdata, len);


    if(gpaypasscanceltrade)
    {
        return;
    }

    transflow_commu_SendPacket_RP(COMMAND_PAYPASS_OUTPARAMSET, 0xFF, tmpdata, len, 0, 0);

}

void sdkPaypassOutComeSendoutparamset(u32 step)
{
    unsigned char tmpdata[100];
    unsigned int len = 0;
    #ifdef EMVB_DEBUG
    unsigned int i;
    #endif

    #ifdef PAYPASS_RRP
    if( step == 0 || step > 50)
    {
        #ifdef EMVB_DEBUG
        Trace("", "\r\n paypass_sendoutparamset: step=%d\r\n", step);
        #endif

        sdkpaypassb_sendoutMeasuredRRPtimeparamset(0);//20160711_lhd
    }
    #endif


    memset(gPaypassOutParameterSet.OutcomeParSet, 0x00, 8);
    gPaypassOutParameterSet.OutcomeParSet[0] &= 0x0F;
    gPaypassOutParameterSet.OutcomeParSet[0] |= (gPaypassOutParameterSet.status << 4);


    gPaypassOutParameterSet.OutcomeParSet[1] &= 0x0F;
    gPaypassOutParameterSet.OutcomeParSet[1] |= (gPaypassOutParameterSet.start << 4);


    gPaypassOutParameterSet.OutcomeParSet[2] &= 0x0F;
    gPaypassOutParameterSet.OutcomeParSet[2] |= (gPaypassOutParameterSet.OnlineResDatainoutParameter << 4);

    gPaypassOutParameterSet.OutcomeParSet[3] &= 0x0F;
    gPaypassOutParameterSet.OutcomeParSet[3] |= (gPaypassOutParameterSet.CVM << 4);


    //20190927_LHD if(gstPaypassTradeParam != NULL)
    {
        if((gPaypassOutParameterSet.CVM & 0x0F) == PAYPASS_OPS_CVM_OBTAINSIGNATURE)
        {
            //gstPaypassTradeParam->bPrintReceipt = 1;
            sdkPaypassSetPrintReceiptStatus(1);
        }
        else
        {
            //	    	gstPaypassTradeParam->bPrintReceipt = 0;
            sdkPaypassSetPrintReceiptStatus(0);

        }
    }


    gPaypassOutParameterSet.OutcomeParSet[4] = 0x00;
    if(gPaypassOutParameterSet.UIRequestOnOutPresent)
    {
        gPaypassOutParameterSet.OutcomeParSet[4] |= 0x80;
    }
    if(gPaypassOutParameterSet.UIRequestOnRestartPresent)
    {
        gPaypassOutParameterSet.OutcomeParSet[4] |= 0x40;
    }
    if(gPaypassOutParameterSet.DataRecordPresent)
    {
        gPaypassOutParameterSet.OutcomeParSet[4] |= 0x20;
    }
    if(gPaypassOutParameterSet.DisDataPresent)
    {
        gPaypassOutParameterSet.OutcomeParSet[4] |= 0x10;
    }
    if(gPaypassOutParameterSet.ReceiptinoutParameter)
    {
        gPaypassOutParameterSet.OutcomeParSet[4] |= 0x08;
        //gbReceipt = 1;
    }
    else
    {
        //	gbReceipt = 0;
    }

    gPaypassOutParameterSet.OutcomeParSet[5] &= 0x0F;
    gPaypassOutParameterSet.OutcomeParSet[5] |= (gPaypassOutParameterSet.AIPinoutParameter << 4);

    gPaypassOutParameterSet.OutcomeParSet[6] = gPaypassOutParameterSet.FieldoffinoutParameter;



    gPaypassOutParameterSet.OutcomeParSet[7] = gPaypassOutParameterSet.RemovalTimeoutinoutParameter;


    memset(tmpdata, 0, sizeof(tmpdata));
    EMVBaseU32ToBcd(tmpdata, step, 4);
    len += 4;

    memcpy(&tmpdata[len], "\xDF\x81\x29", 3);
    len += 3;

    tmpdata[len++] = 8;

    memcpy(&tmpdata[len], (u8 *)&gPaypassOutParameterSet, 8);
    len += 8;

    Trace("", "gpaypasscanceltrade=%d,len=%d\n", gpaypasscanceltrade,len);
    TraceHex("", "paypass_sendoutparamset,tmpdata:", tmpdata, len);

    if(gpaypasscanceltrade)
    {
        return;
    }

    transflow_commu_SendPacket_RP(COMMAND_PAYPASS_OUTPARAMSET, 0xFF, tmpdata, len, 0, 0);

}

void sdkPaypassOutComeSendDisData(int mode)
{
    //u8 tmplenbuf[10];
    u8 *tmpdata;       // �ڴ��Ż�[1200]
    u8 *tmptornrecord; // [1024]
    u32 len, lenpos, tornlogpos, datastartaddr;
    u32 tmptornrecordlen, torndatastartadr = 0;
    u32 t, j, senddatalen;
    #ifdef EMVB_DEBUG
    u32 i;
    #endif
    u8 qPBOCOrMSD;
    EMVBASETAGCVLITEM *item = NULL;
    u8 tagbExist;
    u8 pdoltmpdata[300];
    unsigned int pdoltmpdatalen = 0;


    tmpdata = (u8 *)emvbase_malloc(1200);
    tmptornrecord = (u8 *)emvbase_malloc(1024);

    datastartaddr = 10;
    lenpos = datastartaddr;
    len = lenpos;
    tmptornrecordlen = 0;
    tornlogpos = 0;
    #ifdef EMVB_DEBUG
    Trace("", "sdkPaypassOutComeSendDisData,gPaypassOutParameterSet.selectsucdata=%d,gPaypassOutParameterSet.discretionaryitem.errindicationflag=%d\r\n", gPaypassOutParameterSet.selectsucdata, gPaypassOutParameterSet.discretionaryitem.errindicationflag);
    #endif

    if(gPaypassOutParameterSet.selectsucdata)
    {
        memcpy(&tmpdata[len], "\xDF\x81\x15", 3);
        len += 3;
        tmpdata[len++] = 0x06;
        memcpy(&tmpdata[len], (u8 *)&gstPaypassOutComeErrID, 6);
        len += 6;
        if(gPaypassOutParameterSet.FCIdatalen)
        {
            Packbertlvdata(&tmpdata[0], &len, (u8 *)"\x6F", 1, gPaypassOutParameterSet.FCIdata, gPaypassOutParameterSet.FCIdatalen);
        }
        memcpy(&tmpdata[len], "\xDF\x81\x2E", 3);
        len += 3;
        tmpdata[len++] = gPaypassOutParameterSet.SelectCombDatalen;
        memcpy(&tmpdata[len], gPaypassOutParameterSet.SelectCombData, gPaypassOutParameterSet.SelectCombDatalen);
        len += gPaypassOutParameterSet.SelectCombDatalen;
        memcpy(&tmpdata[len], "\xDF\x81\x2F", 3);
        len += 3;
        tmpdata[len++] = 2;
        memcpy(&tmpdata[len], "\x90\x00", 2);
        len += 2;

        gPaypassOutParameterSet.selectsucdata = 0;
    }
    else if(gPaypassOutParameterSet.discretionaryitem.errindicationflag)
    {
        //error indication
        memcpy(&tmpdata[len], "\xDF\x81\x15", 3);
        len += 3;
        tmpdata[len++] = 0x06;
        memcpy(&tmpdata[len], (u8 *)&gstPaypassOutComeErrID, 6);
        len += 6;
    }
    else
    {
        qPBOCOrMSD = TRANSFLOW_EMVMODE;
        /*if(gstPaypassTradeParam != NULL)
        {
        	qPBOCOrMSD = gstPaypassTradeParam->qPBOCOrMSD;
        }*/

        sdkPaypassGetEmvOrMsdStatus(&qPBOCOrMSD);


        if(qPBOCOrMSD == TRANSFLOW_EMVMODE || pPaypasstorntransactionlogrecord != NULL)
        {
            item = emvbase_avl_gettagitemandstatus(EMVTAG_AppCurcyCode, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], "\x9F\x42", 2);
                len += 2;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }

			#if 0 // removed on 2022.01.01
            item = emvbase_avl_gettagitemandstatus(EMVTAG_BalanceAfterGAC, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], "\xDF\x81\x05", 3);
                len += 3;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }
            else
            {
                item = emvbase_avl_gettagitempointer(EMVTAG_BalanceAfterGAC);
                if(item != NULL)
                {
                    memcpy(&tmpdata[len], "\xDF\x81\x05", 3);
                    len += 3;
                    tmpdata[len++] = 0x00;
                }
            }

            item = emvbase_avl_gettagitemandstatus(EMVTAG_BalanceBeforeGAC, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], "\xDF\x81\x04", 3);
                len += 3;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }
            else
            {
                item = emvbase_avl_gettagitempointer(EMVTAG_BalanceBeforeGAC);
                if(item != NULL)
                {
                    memcpy(&tmpdata[len], "\xDF\x81\x04", 3);
                    len += 3;
                    tmpdata[len++] = 0x00;
                }
            }
			#endif
			
            #ifdef  PAYPASS_DATAEXCHANGE
            item = emvbase_avl_gettagitemandstatus(EMVTAG_DSSummaryStatus, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], EMVTAG_DSSummaryStatus, 3);
                len += 3;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }
            else
            {
                item = emvbase_avl_gettagitempointer(EMVTAG_DSSummaryStatus);
                if(item != NULL)
                {
                    memcpy(&tmpdata[len], EMVTAG_DSSummaryStatus, 3);
                    len += 3;
                    tmpdata[len++] = 0x00;
                }
            }

            item = emvbase_avl_gettagitemandstatus(EMVTAG_DSSummary2, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], EMVTAG_DSSummary2, 3);
                len += 3;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }
            else
            {
                item = emvbase_avl_gettagitempointer(EMVTAG_DSSummary2);
                if(item != NULL)
                {
                    memcpy(&tmpdata[len], EMVTAG_DSSummary2, 3);
                    len += 3;
                    tmpdata[len++] = 0x00;
                }
            }
            item = emvbase_avl_gettagitemandstatus(EMVTAG_DSSummary3, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], EMVTAG_DSSummary3, 3);
                len += 3;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }
            else
            {
                item = emvbase_avl_gettagitempointer(EMVTAG_DSSummary3);
                if(item != NULL)
                {
                    memcpy(&tmpdata[len], EMVTAG_DSSummary3, 3);
                    len += 3;
                    tmpdata[len++] = 0x00;
                }
            }

            item = emvbase_avl_gettagitemandstatus(EMVTAG_POSTGACPDS, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], EMVTAG_POSTGACPDS, 3);
                len += 3;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }
            else
            {
                item = emvbase_avl_gettagitempointer(EMVTAG_POSTGACPDS);
                if(item != NULL)
                {
                    memcpy(&tmpdata[len], EMVTAG_POSTGACPDS, 3);
                    len += 3;
                    tmpdata[len++] = 0x00;
                }
            }

            item = emvbase_avl_gettagitemandstatus(EMVTAG_PREGACPDS, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], EMVTAG_PREGACPDS, 3);
                len += 3;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }
            else
            {
                item = emvbase_avl_gettagitempointer(EMVTAG_PREGACPDS);
                if(item != NULL)
                {
                    memcpy(&tmpdata[len], EMVTAG_PREGACPDS, 3);
                    len += 3;
                    tmpdata[len++] = 0x00;
                }
            }
            //20160629_lhd for 3M24-5321-B01
            item = emvbase_avl_gettagitemandstatus(EMVTAG_AppCapabilitiesInfor, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], EMVTAG_AppCapabilitiesInfor, 2);
                len += 2;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }
            else
            {
                item = emvbase_avl_gettagitempointer(EMVTAG_AppCapabilitiesInfor);
                if(item != NULL)
                {
                    memcpy(&tmpdata[len], EMVTAG_AppCapabilitiesInfor, 2);
                    len += 2;
                    tmpdata[len++] = 0x00;
                }
            }
            #endif

            #if 0 /*Modify by luohuidong at 2019.03.29  17:53�������ط�������  */
            if(pPaypasstorntransactionlogrecord == NULL)
            {
                item = emvbase_avl_gettagitemandstatus(EMVTAG_MeasureRelayResistanceProcessingTime, &tagbExist);
                if(tagbExist)
                {
                    memcpy(&tmpdata[len], "\xDF\x83\x06\x00", 3);
                    len += 3;
                    tmpdata[len++] = item->len;
                    memcpy(&tmpdata[len], item->data, item->len);
                    len += item->len;
                }

                item = emvbase_avl_gettagitemandstatus(EMVTAG_TerminalRelayResistanceEntropy, &tagbExist);
                if(tagbExist)
                {
                    memcpy(&tmpdata[len], "\xDF\x83\x01\x00", 3);
                    len += 3;
                    tmpdata[len++] = item->len;
                    memcpy(&tmpdata[len], item->data, item->len);
                    len += item->len;
                }

                item = emvbase_avl_gettagitemandstatus(EMVTAG_RRPCounter, &tagbExist);
                if(tagbExist)
                {
                    memcpy(&tmpdata[len], "\xDF\x83\x07\x00", 3);
                    len += 3;
                    tmpdata[len++] = item->len;
                    memcpy(&tmpdata[len], item->data, item->len);
                    len += item->len;
                }
            }
            #endif /* if 0 */

            #if 0 /*Modify by luohuidong at 2018.01.12  16:48 */

            //error indication
            memcpy(&tmpdata[len], "\xDF\x81\x15", 3);
            len += 3;
            tmpdata[len++] = 0x06;
            memcpy(&tmpdata[len], (u8 *)&gstPaypassOutComeErrID, 6);
            len += 6;
            #else
            //error indication
            memcpy(&tmpdata[len], "\xDF\x81\x15", 3);
            len += 3;
            if(1 == mode)
            {
                tmpdata[len++] = 0x00;
            }
            else
            {
                tmpdata[len++] = 0x06;
                memcpy(&tmpdata[len], (u8 *)&gstPaypassOutComeErrID, 6);
                len += 6;
            }

            #endif /* if 0 */

            //Third Party data
            item = emvbase_avl_gettagitemandstatus(EMVTAG_PaypassThirdPartyData, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], "\x9F\x6E", 2);
                len += 2;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }

            #ifdef EMVB_DEBUG
            Trace("", "\r\n ggg torn log = %p\r\n", pPaypasstorntransactionlogrecord);
            #endif
            tmptornrecordlen = 0;
            if(pPaypasstorntransactionlogrecord != NULL)
            {
                tmptornrecordlen += 10;
                tornlogpos = tmptornrecordlen;
                torndatastartadr = tornlogpos;

                memcpy(&tmptornrecord[tmptornrecordlen], "\x9F\x02", 2);
                tmptornrecordlen += 2;
                tmptornrecord[tmptornrecordlen++] = 0x06;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->AmtAuthNum, 6);
                tmptornrecordlen += 6;

                if(pPaypasstorntransactionlogrecord->AmtOtherNumexist)
                {

                    memcpy(&tmptornrecord[tmptornrecordlen], "\x9F\x03", 2);
                    tmptornrecordlen += 2;
                    tmptornrecord[tmptornrecordlen++] = 0x06;
                    memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->AmtOtherNum, 6);
                    tmptornrecordlen += 6;
                }


                memcpy(&tmptornrecord[tmptornrecordlen], "\x5A", 1);
                tmptornrecordlen += 1;
                tmptornrecord[tmptornrecordlen++] = pPaypasstorntransactionlogrecord->PANLen;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->PAN, pPaypasstorntransactionlogrecord->PANLen);
                tmptornrecordlen += pPaypasstorntransactionlogrecord->PANLen;

                if(pPaypasstorntransactionlogrecord->PANSeqexist)
                {
                    memcpy(&tmptornrecord[tmptornrecordlen], "\x5F\x34", 2);
                    tmptornrecordlen += 2;
                    tmptornrecord[tmptornrecordlen++] = 1;
                    tmptornrecord[tmptornrecordlen++] = pPaypasstorntransactionlogrecord->PANSeq;
                }


                if(pPaypasstorntransactionlogrecord->PayPassPreBalanceExist)
                {
                    memcpy(&tmptornrecord[tmptornrecordlen], "\xDF\x81\x04", 3);
                    tmptornrecordlen += 3;
                    tmptornrecord[tmptornrecordlen++] = 6;
                    memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->PayPassPreBalance, 6);
                    tmptornrecordlen += 6;
                }

                if(pPaypasstorntransactionlogrecord->CDOL1RelatedLen)
                {
                    Packbertlvdata(&tmptornrecord[0], &tmptornrecordlen, (u8 *)"\xDF\x81\x07", 3, pPaypasstorntransactionlogrecord->CDOL1RelatedData, pPaypasstorntransactionlogrecord->CDOL1RelatedLen);
                }

                //CVM reslut
                memcpy(&tmptornrecord[tmptornrecordlen], "\x9F\x34", 2);
                tmptornrecordlen += 2;
                tmptornrecord[tmptornrecordlen++] = 3;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->CVMResult, 3);
                tmptornrecordlen += 3;


                if(pPaypasstorntransactionlogrecord->DRDOLRelatedLen)
                {
                    Packbertlvdata(&tmptornrecord[0], &tmptornrecordlen, (u8 *)"\xDF\x81\x13", 3, pPaypasstorntransactionlogrecord->DRDOLRelatedData, pPaypasstorntransactionlogrecord->DRDOLRelatedLen);
                }
                #ifdef PAYPASS_DATAEXCHANGE
                if(pPaypasstorntransactionlogrecord->DSSummary1Len)
                {
                    Packbertlvdata(&tmptornrecord[0], &tmptornrecordlen, (u8 *)"\x9F\x7D", 2, pPaypasstorntransactionlogrecord->DSSummary1, pPaypasstorntransactionlogrecord->DSSummary1Len);
                }

                memcpy(&tmptornrecord[tmptornrecordlen], "\xDF\x81\x28", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 1;
                tmptornrecord[tmptornrecordlen++] = pPaypasstorntransactionlogrecord->IDSStatus;
                #endif

                //IFD Ser
                if(pPaypasstorntransactionlogrecord->InterfaceDeviceSerialNumberExist)
                {
                    memcpy(&tmptornrecord[tmptornrecordlen], "\x9F\x1E", 2);
                    tmptornrecordlen += 2;
                    tmptornrecord[tmptornrecordlen++] = 8;
                    memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->InterfaceDeviceSerialNumber, 8);
                    tmptornrecordlen += 8;
                }

                #ifdef TORNLOGDEBUG
                Trace("", "\r\npPaypasstorntransactionlogrecord->PDOLRelatedLen send = %d\r\n");
                #endif

                memset(pdoltmpdata, 0, sizeof(pdoltmpdata));
                pdoltmpdatalen = 0;
                if(pPaypasstorntransactionlogrecord->PDOLRelatedLen)
                {
                    //Packbertlvdata(&tmptornrecord[0],&tmptornrecordlen,(u8 *)"\xDF\x81\x11",3,pPaypasstorntransactionlogrecord->PDOLRelatedData,pPaypasstorntransactionlogrecord->PDOLRelatedLen);
                    pdoltmpdata[pdoltmpdatalen++] = 0x83;

                    if(((pPaypasstorntransactionlogrecord->PDOLRelatedLen) & 0x80) > 0)				 //�������ֽ�
                    {
                        pdoltmpdata[pdoltmpdatalen++] = 0x81;
                        pdoltmpdata[pdoltmpdatalen++] = pPaypasstorntransactionlogrecord->PDOLRelatedLen; //ֻ��һ���ֽ�
                    }
                    else
                    {
                        pdoltmpdata[pdoltmpdatalen++] = pPaypasstorntransactionlogrecord->PDOLRelatedLen; //ֻ��һ���ֽ�
                    }
                    memcpy(&pdoltmpdata[pdoltmpdatalen], pPaypasstorntransactionlogrecord->PDOLRelatedData, pPaypasstorntransactionlogrecord->PDOLRelatedLen);
                    pdoltmpdatalen += pPaypasstorntransactionlogrecord->PDOLRelatedLen;
                }
                else
                {
                    memcpy(pdoltmpdata, "\x83\x00", 2);
                    pdoltmpdatalen = 2;
                }
                Packbertlvdata(&tmptornrecord[0], &tmptornrecordlen, (u8 *)"\xDF\x81\x11", 3, pdoltmpdata, pdoltmpdatalen);

                //torn log�Ƿ�ֻ������TC��ʱ�����?
                memcpy(&tmptornrecord[tmptornrecordlen], "\xDF\x81\x14", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 1;
                tmptornrecord[tmptornrecordlen++] = pPaypasstorntransactionlogrecord->ReferenceControlParameter;


                memcpy(&tmptornrecord[tmptornrecordlen], "\x9F\x33", 2);
                tmptornrecordlen += 2;
                tmptornrecord[tmptornrecordlen++] = 3;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->TermCapab, 3);
                tmptornrecordlen += 3;

                if(pPaypasstorntransactionlogrecord->CountryCodeexist)
                {
                    memcpy(&tmptornrecord[tmptornrecordlen], "\x9F\x1A", 2);
                    tmptornrecordlen += 2;
                    tmptornrecord[tmptornrecordlen++] = 2;
                    memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->CountryCode, 2);
                    tmptornrecordlen += 2;
                }


                memcpy(&tmptornrecord[tmptornrecordlen], "\x9F\x35", 2);
                tmptornrecordlen += 2;
                tmptornrecord[tmptornrecordlen++] = 1;
                tmptornrecord[tmptornrecordlen++] = pPaypasstorntransactionlogrecord->TermType;

                memcpy(&tmptornrecord[tmptornrecordlen], "\x95", 1);
                tmptornrecordlen += 1;
                tmptornrecord[tmptornrecordlen++] = 5;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->TVR, 5);
                tmptornrecordlen += 5;

                if(pPaypasstorntransactionlogrecord->TransCateCodeexist)
                {
                    memcpy(&tmptornrecord[tmptornrecordlen], "\x9F\x53", 2);
                    tmptornrecordlen += 2;
                    tmptornrecord[tmptornrecordlen++] = 1;
                    tmptornrecord[tmptornrecordlen++] = pPaypasstorntransactionlogrecord->TransCateCode;
                }

                if(pPaypasstorntransactionlogrecord->TransCurcyCodeexist)
                {
                    memcpy(&tmptornrecord[tmptornrecordlen], "\x5F\x2A", 2);
                    tmptornrecordlen += 2;
                    tmptornrecord[tmptornrecordlen++] = 2;
                    memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->TransCurcyCode, 2);
                    tmptornrecordlen += 2;
                }


                memcpy(&tmptornrecord[tmptornrecordlen], "\x9A", 1);
                tmptornrecordlen += 1;
                tmptornrecord[tmptornrecordlen++] = 3;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->TransDate, 3);
                tmptornrecordlen += 3;


                memcpy(&tmptornrecord[tmptornrecordlen], "\x9F\x21", 2);
                tmptornrecordlen += 2;
                tmptornrecord[tmptornrecordlen++] = 3;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->TransTime, 3);
                tmptornrecordlen += 3;


                memcpy(&tmptornrecord[tmptornrecordlen], "\x9C", 1);
                tmptornrecordlen += 1;
                tmptornrecord[tmptornrecordlen++] = 1;
                tmptornrecord[tmptornrecordlen++] = pPaypasstorntransactionlogrecord->TransTypeValue;

                memcpy(&tmptornrecord[tmptornrecordlen], "\x9F\x37", 2);
                tmptornrecordlen += 2;
                tmptornrecord[tmptornrecordlen++] = 4;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->UnpredictNum, 4);
                tmptornrecordlen += 4;

                #ifdef PAYPASS_DATAEXCHANGE
                #if 0 /*Modify by luohuidong at 2017.04.09  11:7 */
                memcpy(&tmptornrecord[tmptornrecordlen], "\xFF\x81\x15\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 4;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->TerminalRelayResistanceEntropy, 4);

                memcpy(&tmptornrecord[tmptornrecordlen], "\xFF\x81\x16\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 4;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->DeviceRelayResistanceEntropy, 4);

                memcpy(&tmptornrecord[tmptornrecordlen], "\xFF\x81\x17\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 2;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->MinTimeForProcessingRelayResistanceAPDU, 2);

                memcpy(&tmptornrecord[tmptornrecordlen], "\xFF\x81\x18\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 2;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->MaxTimeForProcessingRelayResistanceAPDU, 2);

                memcpy(&tmptornrecord[tmptornrecordlen], "\xFF\x81\x19\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 2;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->DeviceEstimatedTransTForRRRAPDU, 2);

                memcpy(&tmptornrecord[tmptornrecordlen], "\xFF\x81\x1A\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 2;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->MeasureRelayResistanceProcessingTime, 2);
                #else
                memcpy(&tmptornrecord[tmptornrecordlen], "\xDF\x83\x01\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 4;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->TerminalRelayResistanceEntropy, 4);
                tmptornrecordlen += 4;

                memcpy(&tmptornrecord[tmptornrecordlen], "\xDF\x83\x02\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 4;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->DeviceRelayResistanceEntropy, 4);
                tmptornrecordlen += 4;

                memcpy(&tmptornrecord[tmptornrecordlen], "\xDF\x83\x03\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 2;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->MinTimeForProcessingRelayResistanceAPDU, 2);
                tmptornrecordlen += 2;

                memcpy(&tmptornrecord[tmptornrecordlen], "\xDF\x83\x04\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 2;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->MaxTimeForProcessingRelayResistanceAPDU, 2);
                tmptornrecordlen += 2;


                memcpy(&tmptornrecord[tmptornrecordlen], "\xDF\x83\x05\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 2;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->DeviceEstimatedTransTForRRRAPDU, 2);
                tmptornrecordlen += 2;

                memcpy(&tmptornrecord[tmptornrecordlen], "\xDF\x83\x06\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 2;
                memcpy(&tmptornrecord[tmptornrecordlen], pPaypasstorntransactionlogrecord->MeasureRelayResistanceProcessingTime, 2);
                tmptornrecordlen += 2;

                #if 1 /*Modify by luohuidong at 2019.03.29  16:51 add */
                memcpy(&tmptornrecord[tmptornrecordlen], "\xDF\x83\x07\x00", 3);
                tmptornrecordlen += 3;
                tmptornrecord[tmptornrecordlen++] = 1;
                tmptornrecord[tmptornrecordlen++] = pPaypasstorntransactionlogrecord->RRP_counter;
                #endif /* if 1 */

                #endif /* if 0 */
                #endif

                emvbase_free(pPaypasstorntransactionlogrecord);
                pPaypasstorntransactionlogrecord = NULL;


                senddatalen = tmptornrecordlen - torndatastartadr;

                if(senddatalen < 128)
                {
                    tmptornrecord[--tornlogpos] = tmptornrecordlen - torndatastartadr;

                }
                else
                {
                    t = 0;
                    while(senddatalen)
                    {
                        t++;
                        senddatalen = senddatalen >> 8;
                    }

                    senddatalen = tmptornrecordlen - torndatastartadr;
                    for(j = t; j > 0; j--)
                    {
                        tmptornrecord[--tornlogpos] = senddatalen % 256;
                        senddatalen = senddatalen >> 8;
                    }
                    tmptornrecord[--tornlogpos] = 0x80 | t;

                }

                tornlogpos -= 3;
                memcpy(&tmptornrecord[tornlogpos], "\xFF\x81\x01", 3);

            }

        }
        else
        {
            #if 1 /*Modify by luohuidong at 2016.10.07  17:3 */
            item = emvbase_avl_gettagitemandstatus(EMVTAG_AppCapabilitiesInfor, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], "\x9F\x5D", 2);
                len += 2;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }
            #endif /* if 0 */

            item = emvbase_avl_gettagitemandstatus(EMVTAG_Paypassconverttrack1, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], "\xDF\x81\x2A", 3);
                len += 3;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }

            item = emvbase_avl_gettagitemandstatus(EMVTAG_Paypassconverttrack2, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], "\xDF\x81\x2B", 3);
                len += 3;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }

            #if 0 /*Modify by luohuidong at 2018.01.12  16:48 */

            //error indication
            memcpy(&tmpdata[len], "\xDF\x81\x15", 3);
            len += 3;
            tmpdata[len++] = 0x06;
            memcpy(&tmpdata[len], (u8 *)&gstPaypassOutComeErrID, 6);
            len += 6;
            #else
            //error indication
            memcpy(&tmpdata[len], "\xDF\x81\x15", 3);
            len += 3;
            if(1 == mode)
            {
                tmpdata[len++] = 0x00;
            }
            else
            {
                tmpdata[len++] = 0x06;
                memcpy(&tmpdata[len], (u8 *)&gstPaypassOutComeErrID, 6);
                len += 6;
            }
            #endif

            //Third Party data
            item = emvbase_avl_gettagitemandstatus(EMVTAG_PaypassThirdPartyData, &tagbExist);
            if(tagbExist)
            {
                memcpy(&tmpdata[len], "\x9F\x6E", 2);
                len += 2;
                tmpdata[len++] = item->len;
                memcpy(&tmpdata[len], item->data, item->len);
                len += item->len;
            }

        }
    }

    if(tmptornrecordlen - tornlogpos)
    {
        #ifdef EMVB_DEBUG
        Trace("", "\r\n addde torn log:%d\r\n", tmptornrecordlen - tornlogpos);
        /*		for(i = 0;i < tmptornrecordlen - tornlogpos;i++)
        		{
        			Trace("","%02x ",tmptornrecord[tornlogpos+i]);
        		}
                Trace("","\r\n");*/
        TraceHex("", "data:", tmptornrecord + tornlogpos, tmptornrecordlen - tornlogpos);
        #endif
        memcpy(&tmpdata[len], &tmptornrecord[tornlogpos], tmptornrecordlen - tornlogpos);
        len += tmptornrecordlen - tornlogpos;
    }

    senddatalen = len - datastartaddr;

    if(senddatalen < 128)
    {
        tmpdata[--lenpos] = len - datastartaddr;

    }
    else
    {
        t = 0;
        while(senddatalen)
        {
            t++;
            senddatalen = senddatalen >> 8;
        }

        senddatalen = len - datastartaddr;
        for(j = t; j > 0; j--)
        {
            tmpdata[--lenpos] = senddatalen % 256;
            senddatalen = senddatalen >> 8;
        }
        tmpdata[--lenpos] = 0x80 | t;

    }


    lenpos -= 3;
    memcpy(&tmpdata[lenpos], "\xFF\x81\x06", 3);

    senddatalen = len - lenpos;


    #ifdef EMVB_DEBUG
    Trace("", "\r\n adgc paypass_sendDisData:%d\r\n", senddatalen);
    TraceHex("", "send data", tmpdata + lenpos, senddatalen);
    Trace("", "\r\n gpaypasscanceltrade=%d\r\n", gpaypasscanceltrade);
    #endif

    if(gpaypasscanceltrade)
    {
        emvbase_free(tmptornrecord);
        emvbase_free(tmpdata);
        return;

    }

    emvbase_free(tmptornrecord);

    transflow_commu_SendPacket_RP(COMMAND_PAYPASS_DISCRENTDATA, 0xFF, &tmpdata[lenpos], senddatalen, 0, 0);

    emvbase_free(tmpdata);


}

void sdkPaypassOutComeSenduserinterfacerequestdata(unsigned int step)
{
    unsigned char tmpdata[100];
    unsigned int len = 0;
    #ifdef SXL_DEBUG
    unsigned int i;
    #endif
    unsigned char MessageID;
    unsigned char languagepre[8];
    unsigned char tempStatus;

    memset(tmpdata, 0, sizeof(tmpdata));
    EMVBaseU32ToBcd(tmpdata, step, 4);

    len += 4;
    memcpy(&tmpdata[len], "\xDF\x81\x16", 3);
    len += 3;

    tmpdata[len++] = 22;

    gPaypassUserInterfaceReqData.ValueQualifier = gPaypassUserInterfaceReqData.ValueQualifier << 4;

    memcpy(&tmpdata[len], (u8 *)&gPaypassUserInterfaceReqData, 22);
    len += 22;


    #ifdef SXL_DEBUG
    Trace("", "\r\npaypass_sendDisData:\r\n");
    TraceHex("", "tmpdata", tmpdata, len);
    #endif

    tempStatus = gPaypassUserInterfaceReqData.Status;
    //�������Ҫ����?
    memcpy(languagepre, gPaypassUserInterfaceReqData.LanguagePreference, 8);
    MessageID = gPaypassUserInterfaceReqData.MessageID;
    memset(&gPaypassUserInterfaceReqData, 0, sizeof(PAYPASS_USERINTERFACEREQDATA));
    gPaypassUserInterfaceReqData.MessageID = MessageID;
    gPaypassUserInterfaceReqData.Status = 0xFF;

    memcpy(gPaypassUserInterfaceReqData.LanguagePreference, languagepre, 8);

    if(tempStatus == PAYPASS_USERREQDATA_STATUS_READYTOREAD)  //sxl?20150428 Ҫɾ��������Ϣ
    {
        sdkmSleep(300);
    }

    #if 0//20160712_lhd  for 3G27-0252-02 test use

    sdkmSleep(300);

    #endif

    if(gpaypasscanceltrade)
    {
        return;
    }

    transflow_commu_SendPacket_RP(COMMAND_PAYPASS_USERREQDATA, 0xFF, tmpdata, len, 0, 0);

    if(tempStatus == PAYPASS_USERREQDATA_STATUS_READYTOREAD)
    {
        sdkmSleep(300);
        //Trace("","\r\nready to read\r\n");
    }

}

u8 sdkPaypassOutComeformsendpaypasspredata(u8 *carddata, u32 *carddatalen)
{
    u32 len = 0;
    u8 datetime[20];
    u32 tmplen;
    u8 *tmp;   //
    s32 ret;
    //u8 ifd4use = 0;
    //u32 d4lenpos;
    //u32 d4datalen = 0;
    u16 tagdatalen;


    tmp = (u8 *)emvbase_malloc(1024);

    Trace("", "gstPaypassTradeParam->TransResult=%d", gstPaypassTradeParam->TransResult);
    Trace("", "gstPaypassTradeParam->qPBOCOrMSD=%d", gstPaypassTradeParam->qPBOCOrMSD);

    if(gstPaypassTradeParam->TransResult == RLT_EMV_OFFLINE_DECLINE)
    {
        carddata[len++] =  0x00;
    }
    else if(gstPaypassTradeParam->TransResult == RLT_EMV_OFFLINE_APPROVE)
    {
        carddata[len++] =  0x40;
    }
    else
    {
        carddata[len++] =  0x80;
    }



    if(gstPaypassTradeParam->qPBOCOrMSD == TRANSFLOW_MSDMODE)
    {
        carddata[len++] = 0x07;
    }
    else if(gstPaypassTradeParam->qPBOCOrMSD == TRANSFLOW_EMVMODE)
    {
        carddata[len++] = 0x91;
    }
    else
    {
        emvbase_free(tmp);
        return RC_FAILURE;
    }

    //��ȡ����ʱ��
    emvbase_avl_gettagvalue_all(EMVTAG_TransDate, tmp, &tagdatalen);
    if(tmp[0] > 0x50)
    {
        datetime[0] = 0x19;
    }
    else
    {
        datetime[0] = 0x20;
    }
    memcpy(&datetime[1], tmp, 3);
    emvbase_avl_gettagvalue_all(EMVTAG_TransTime, tmp, &tagdatalen);
    memcpy(&datetime[4], tmp, 3);


    memcpy(&carddata[len], datetime, 7);
    //EMVBcdToAsc(&carddata[len],datetime,7);
    len += 7;

    if(gstPaypassTradeParam->qPBOCOrMSD == TRANSFLOW_EMVMODE)
    {

    }
    else  //������������
    {
        #if 0//20160713_lhd for case 3G27-1100-a02
        //ת������һ�ŵ�����
        emvbase_avl_gettagvalue_all(EMVTAG_Paypassconverttrack1, tmp, &tagdatalen);
        if(tagdatalen)
        {
            carddata[len++] = 0xD1;
            tmplen = tagdatalen;
            if(tmplen > 80)
            {
                tmplen = 80;
            }
            carddata[len++] = tmplen;
            memcpy(&carddata[len], tmp, tmplen);
            len += tmplen;
        }

        //ת�����Ķ��ŵ�����
        emvbase_avl_gettagvalue_all(EMVTAG_Paypassconverttrack2, tmp, &tagdatalen);
        if(tagdatalen)
        {
            carddata[len++] = 0xD2;
            tmplen = tagdatalen;
            /*
            if(tmplen > 19)
            {
            	tmplen = 19;
            }
            */
            carddata[len++] = tmplen;
            memcpy(&carddata[len], tmp, tmplen);
            len += tmplen;
        }
        #endif
    }
    #if 1
    if(gstPaypassTradeParam->qPBOCOrMSD == TRANSFLOW_EMVMODE)
    {
        ret = EMVB_ZipPagData(TRADETYPE_PAYPASSCHIPPREPAY, tmp, &tmplen, 0, 0, 0);
    }
    else
    {
        ret = EMVB_ZipPagData(TRADETYPE_PAYPASSMAGPREPAY, tmp, &tmplen, 0, 0, 0);
    }
    #endif
    Trace("", "out EMVB_ZipPagData");
    if(ret != RLT_EMV_OK)
    {
        emvbase_free(tmp);
        return RC_FAILURE;
    }

    //D3
    carddata[len++] = 0xD3;
    if(tmplen > 255)
    {
        tmplen = 255;
    }
    carddata[len++] = tmplen;
    memcpy(&carddata[len], tmp, tmplen);
    len += tmplen;


    //d4 online pin
    emvbase_avl_gettagvalue_all(EMVTAG_PIN, tmp, &tagdatalen);
    if(tagdatalen == 8)  //��TREE����?
    {

        carddata[len++] = 0xD5;
        memcpy(&carddata[len], tmp, 8);
        len += 8;


    }


    *carddatalen = len;
    emvbase_free(tmp);
    return 0;
}


s32 sdkPaypassOutComeSendpaypassbag(void)
{

    s32 retCode = RLT_EMV_OK;
    s32 ret;
    u8 *returndata;    //[1024]
    u32 returndatalen;

    u32 receiveovertimer;
    u32 greenledtimer = TIMER500MSVALUE;



    #ifdef SXL_DEBUG
    Trace("", "\r\ntransflow_sendpaypassbag %d %d %d\r\n", gPaypassOutParameterSet.opssendflag, gPaypassOutParameterSet.DisDataPresent, gPaypassUserInterfaceReqData.sendMsgFlag);
    #endif

    if(gPaypassOutParameterSet.opssendflag)
    {
        sdkPaypassOutComeSendoutparamset(1);
        gPaypassOutParameterSet.opssendflag = 0;

        if(gPaypassOutParameterSet.DisDataPresent)
        {
            sdkPaypassOutComeSendDisData(0);
            gPaypassOutParameterSet.DisDataPresent = 0;
        }
    }


    if(gPaypassUserInterfaceReqData.sendMsgFlag)
    {
        sdkPaypassOutComeSenduserinterfacerequestdata(1);
        gPaypassUserInterfaceReqData.sendMsgFlag = 0;
    }
    #if 1

    returndata = (u8 *)emvbase_malloc(1024);


    ret = sdkPaypassOutComeformsendpaypasspredata(&returndata[1], &returndatalen);
    Trace("", "sdkPaypassOutComeformsendpaypasspredata ret=%d", ret);
    if(ret != 0)
    {
        transflow_commu_SendPacket_RP(COMMAND_PAYPASS, gSerialNo, NULL, 0, ret, 0);
        emvbase_free(returndata);
        return ret;
    }
    Trace("", "transflow_sendauthorRQorOnlineFina ret=%d", ret);
    ret = transflow_sendauthorRQorOnlineFina(PAYPASSAPP, returndata, &returndatalen);
    if(ret != 0)
    {
        transflow_commu_SendPacket_RP(COMMAND_PAYPASS, gSerialNo, NULL, 0, ret, 0);
        emvbase_free(returndata);
        return ret;
    }

    Trace("", "transflow_commu_SendPacket_RP  ret=%d", ret);
    transflow_commu_SendPacket_RP(COMMAND_PAYPASS, gSerialNo, returndata, returndatalen, RC_DATA, 0);
    emvbase_free(returndata);



    receiveovertimer = 1500;

    receiveovertimer = sdkPaypasstransfertimervalue(receiveovertimer);

    unsigned int timer2 = sdkTimerGetId();
    Trace("", "%u,%u  ret=%d", sdkTimerGetId(), timer2, ret);
    while(1)
    {
        transflow_parserxdata(0);
        if(Rx_Valid == 2)
        {
            Trace("", "gCommData.command=0x%x\n", gCommData.command);
            if(gCommData.command == COMMAND_PAYRESET)
            {
                transflow_payreset(gCommData.serialno, &gCommData.data[COMMHEADDATALEN], gCommData.datalen);
                retCode = qPBOC_RESETCOMMAND;
                break;
            }
            else if(gCommData.command == COMMAND_POLL)
            {
                transflow_poll();
            }
            else if(gCommData.command == COMMAND_DEALONLINE)
            {
                retCode = transflowb_dealonlinedata(gCommData.serialno, &gCommData.data[COMMHEADDATALEN], gCommData.datalen);
                break;
            }
            else if(gCommData.command == COMMAND_DISPLAYSTATUS)
            {
                transflow_displaystatus(gCommData.serialno, &gCommData.data[COMMHEADDATALEN], gCommData.datalen);
                ret = qPBOC_COMPLETE;
                break;
            }
        }
        else if( 1 == sdkTimerIsEnd(timer2, receiveovertimer))
        {
            //  PostOperatePaypassErr(qPBOC_RECEIVEDOVERTIME);
            emvbase_avl_createsettagvalue(EMVTAG_AuthRespCode, "\x00\x00", 2);
            //retCode = RLT_EMV_OK;
            retCode = qPBOC_RECEIVEDOVERTIME;

            break;
        }
        Rx_Valid = 0;
    }

    if(retCode == RLT_EMV_OK)  //���ƴ���״̬
    {
        //transflow_controlled(LED_GREEN,LED_OPEN);  //sxl?20150948
    }
    else if(retCode == qPBOC_RECEIVEDOVERTIME)
    {
        retCode = RLT_EMV_OK;
    }
    else
    {
        //	PostOperateqPBOCErr(qPBOC_RECEIVEBAGERR);
    }
    #endif
    Trace("", "out sendpaypass bag  ret=%d", ret);
    return retCode;
}

s32 transflowb_paypasssendofflinebag(void)
{
    s32 retCode = 0;
    s32 ret;
    u8 *returndata;       //[1024]
    u32 returndatalen;


    if(gPaypassOutParameterSet.opssendflag)
    {
        sdkPaypassOutComeSendoutparamset(0);
        gPaypassOutParameterSet.opssendflag = 0;

        if(gPaypassOutParameterSet.DisDataPresent)
        {
            sdkPaypassOutComeSendDisData(0);
            gPaypassOutParameterSet.DisDataPresent = 0;
        }
    }


    if(gPaypassUserInterfaceReqData.sendMsgFlag)
    {
        sdkPaypassOutComeSenduserinterfacerequestdata(0);
        gPaypassUserInterfaceReqData.sendMsgFlag = 0;
    }
    #if 1
    returndata = (u8 *)emvbase_malloc(1024);

    ret = sdkPaypassOutComeformsendpaypasspredata(&returndata[1], &returndatalen);
    if(ret == RC_SUCCESS)
    {
        ret = managerecordb_offlineapproved(PAYPASSAPP, returndata, returndatalen);
    }

    emvbase_free(returndata);
    #endif

    return retCode;


}
#else

void sdkPaypassOutComeSenduserinterfacerequestdata(unsigned int step)
{
    return ;
}

void sdkPaypassOutComeSendoutparamset(u32 step)
{
    ;
}

void sdkPaypassOutComeSendDisData(int mode)
{
    ;
}
void sdkPaypassOutComeSendendapplicationdatarecord(void)
{
    ;
}

#endif


